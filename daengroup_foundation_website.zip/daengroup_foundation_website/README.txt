DAENGROUP FOUNDATION WEBSITE
============================

Included pages:
- index.html (Home)
- about.html
- programs.html
- student-welfare.html
- social-welfare.html
- startup-support.html
- gallery.html
- contact.html
- styles.css
- script.js

HOW TO PREVIEW
1. Extract the ZIP.
2. Open index.html in a modern browser.
3. Navigate using the top menu.

BEFORE PUBLISHING
- Add official phone, email and social-media links after verification.
- Replace the Gallery placeholder tiles with real photographs and captions.
- Connect the contact form to an approved backend, email service or form provider. It currently displays a demo message only.
- Review all public-facing copy and legal/compliance language before launch.
- Add a privacy policy and any other notices required for the site's actual data collection.

CONTENT BASIS
Company name, incorporation date, registered office, CIN and program themes are based on the supplied incorporation certificate and Memorandum of Association. Program pages describe intended focus areas, not confirmed events, grants, beneficiaries or impact results.
